#pragma once
#include "RigidBodyClass.h"


class PhysicsClass
{
public:
	PhysicsClass();
	~PhysicsClass();
};

